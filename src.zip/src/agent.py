import time
import os
import json
import numpy as np
import faiss
import wikipedia
import re
import trafilatura
from ddgs import DDGS
from scipy import sparse
from src.query_engine import CRS
from src.embedders import MultimodalEmbedder
from src.wikidata import WikidataFetcher
from src.builder import ConceptBuilder


class LearningAgent:
    def __init__(self, root="data"):
        print("🤖 Agent waking up... (Loading Memory)")
        self.root = root
        self.crs = CRS(root)
        self.embedder = MultimodalEmbedder()
        self.wiki = WikidataFetcher()
        self.builder = ConceptBuilder(output_dir=f"{root}/concepts")

        self.UNKNOWN_THRESHOLD = 0.85
        self.items_learned_session = 0
        self.MAINTENANCE_TRIGGER = 5
        self.label_index_path = f"{root}/metadata/label_index.json"
        self.label_index = self._load_label_index()

    def _load_label_index(self):
        if os.path.exists(self.label_index_path):
            with open(self.label_index_path, 'r') as f: return json.load(f)
        return {}

    def _save_label_index(self):
        with open(self.label_index_path, 'w') as f: json.dump(self.label_index, f)

    def extract_subject(self, sentence):
        """Intelligent Subject Extraction"""
        # 1. Strip common question phrases
        patterns = [
            r"^what's happening with\s+", r"^what is happening in\s+",
            r"^what is\s+", r"^who is\s+", r"^what's\s+",
            r"^tell me about\s+", r"^do you know\s+", r"^latest news on\s+"
        ]
        clean_q = sentence
        for p in patterns:
            clean_q = re.sub(p, "", clean_q, flags=re.IGNORECASE)

        # 2. Strip punctuation
        clean_q = clean_q.replace('?', '').replace('!', '').strip()
        return clean_q

    def get_web_data(self, query):
        """Scrapes the live web using DuckDuckGo"""
        print(f"   🌍 Searching Live Web for '{query}'...")
        try:
            # DuckDuckGo Search
            results = DDGS().text(query, max_results=1)
            if not results: return None, None

            top_hit = results[0]
            url = top_hit['href']
            print(f"   🔗 Crawling URL: {url}")

            # Trafilatura Scrape (Clean text only)
            downloaded = trafilatura.fetch_url(url)
            if downloaded:
                text = trafilatura.extract(downloaded)
                if text:
                    # Return first 600 chars + Source
                    return text[:600] + "...", url

            # Fallback to snippet
            return top_hit['body'], url
        except Exception as e:
            print(f"   ⚠️ Web Error: {e}")
            return None, None

    def ask(self, user_query):
        # 1. Logic to detect "News" intent vs "Fact" intent
        is_news_query = any(w in user_query.lower() for w in ['news', 'latest', 'happening', 'price', 'today'])

        search_term = self.extract_subject(user_query)
        clean_key = search_term.lower().strip()

        print(f"\n🤔 Query: '{user_query}'")
        print(f"   🔍 Subject: '{search_term}' {'(News Mode)' if is_news_query else ''}")

        # 2. Symbolic Search (Skip if user explicitly wants news, as stored data might be old)
        if not is_news_query and clean_key in self.label_index:
            cid = self.label_index[clean_key]
            print(f"   📖 Found in Symbolic Index.")
            concept = self.crs.get_concept(cid)
            if concept: return self.format_concept(concept)

        # 3. Vector Search
        query_vec = self.embedder.embed_text(search_term)
        if not query_vec: return "Error."
        query_vec_np = np.array([query_vec]).astype('float32')
        D, I = self.crs.index.search(query_vec_np, k=1)

        best_idx = I[0][0]
        distance = D[0][0]
        print(f"   Internal Memory Distance: {distance:.4f}")

        # 4. Decision: Learn?
        # Force learn if it's a news query OR low confidence
        if is_news_query or best_idx == -1 or distance > self.UNKNOWN_THRESHOLD:
            print(f"   🌑 Concept not found (or News requested).")

            new_cid = self.learn_concept(search_term, force_web=is_news_query)

            if new_cid:
                self.check_maintenance()
                concept = self.crs.get_concept(new_cid)
                print("   ✅ Learned & Loaded.")
                if concept: return self.format_concept(concept)
            else:
                return "❌ I looked on the Web but couldn't find good info."

        # Fallback
        cid = self.crs.faiss_map[best_idx]
        concept = self.crs.get_concept(cid)
        return self.format_concept(concept)

    def learn_concept(self, query, force_web=False):
        # A. Get Graph Data (Always try Wikidata for ID/Props)
        qid = self.wiki.search_entity(query)
        props, rels = [], []
        if qid:
            print(f"   🔗 Linking to Knowledge Graph ID: {qid}")
            _, _, props, rels = self.wiki.get_details(qid)

        # B. Get Text Content
        final_text = ""
        source_url = ""

        # Strategy 1: Wikipedia (Best for General Knowledge)
        if not force_web:
            try:
                final_text = wikipedia.summary(query, sentences=3)
                source_url = "Wikipedia"
            except:
                pass

        # Strategy 2: Live Web (If Wiki failed OR News requested)
        if not final_text:
            web_text, url = self.get_web_data(query)
            if web_text:
                final_text = web_text
                source_url = url

        # Strategy 3: Wikidata Description (Last Resort)
        if not final_text and qid:
            wiki_desc, _, _, _ = self.wiki.get_details(qid)
            final_text = wiki_desc
            source_url = "Wikidata"

        if not final_text: return None

        # Add Source
        props.append({'key': 'source', 'value': source_url})

        # C. Build
        concept_id = f"wiki_{qid}" if qid else f"web_{hash(query)}"
        text_context = f"{query}: {final_text}"
        text_emb = self.embedder.embed_text(text_context)

        concept_data = {
            'id': concept_id,
            'label': query,
            'definition': final_text,
            'text_embedding': text_emb,
            'relations': rels,
            'properties': props
        }

        self.builder.build_concept(concept_data)

        vec_np = np.array([text_emb]).astype('float32')
        self.crs.index.add(vec_np)
        new_idx = self.crs.index.ntotal - 1
        self.crs.faiss_map[new_idx] = concept_data['id']
        self.label_index[query.lower()] = concept_data['id']
        self._save_label_index()

        faiss.write_index(self.crs.index, f"{self.root}/vectors/text.faiss")
        with open(f"{self.root}/metadata/faiss_id_map.json", 'w') as f:
            json.dump(self.crs.faiss_map, f)

        return concept_data['id']

    def format_concept(self, concept):
        label = concept.Label().decode('utf-8')
        definition = concept.Definition().decode('utf-8')
        props = []
        p_len = concept.PropertiesLength()
        for i in range(p_len):
            p = concept.Properties(i)
            key = p.Key().decode('utf-8')
            val = p.Value().decode('utf-8')
            if key not in ['wikidata_id', 'pos']:
                props.append(f"{key}: {val}")

        prop_str = "\n   ".join(props[:5])
        if prop_str: prop_str = f"\n   [Data]\n   {prop_str}"
        return f"[{label}]\n   {definition}\n{prop_str}"

    def check_maintenance(self):
        if self.items_learned_session >= self.MAINTENANCE_TRIGGER:
            print(f"\n   🛠️ MAINTENANCE: Rebuilding Graph Matrix...")
            self.rebuild_graph()
            self.items_learned_session = 0

    def rebuild_graph(self):
        all_ids = list(self.crs.faiss_map.values())
        id_to_int = {cid: i for i, cid in enumerate(all_ids)}
        row_ind, col_ind, data_val = [], [], []
        for cid in all_ids:
            c = self.crs.get_concept(cid)
            if not c: continue
            u = id_to_int[cid]
            rels_len = c.RelationsLength()
            for i in range(rels_len):
                r = c.Relations(i)
                target = r.TargetId().decode('utf-8')
                if target in id_to_int:
                    v = id_to_int[target]
                    row_ind.append(u)
                    col_ind.append(v)
                    data_val.append(1)
        size = len(all_ids)
        adj_matrix = sparse.csr_matrix((data_val, (row_ind, col_ind)), shape=(size, size))
        np.savez(f"{self.root}/graph/csr_arrays.npz", indptr=adj_matrix.indptr, indices=adj_matrix.indices,
                 data=adj_matrix.data)
        with open(f"{self.root}/graph/node_map.json", 'w') as f:
            json.dump(id_to_int, f)
        self.crs.graph = adj_matrix
        self.crs.node_map = id_to_int
        self.crs.rev_node_map = {v: k for k, v in id_to_int.items()}


if __name__ == "__main__":
    os.environ["HF_HUB_DISABLE_SYMLINKS_WARNING"] = "1"
    agent = LearningAgent()
    print("Welcome to Stage 2 (Hybrid Web + Wiki).")
    while True:
        q = input("\nUser> ")
        if q.lower() == 'q': break
        print(f"Agent> {agent.ask(q)}")